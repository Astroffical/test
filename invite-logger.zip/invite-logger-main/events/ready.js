module.exports = async (client) => {
    client.functions.log("Ready.", "READY");
};
